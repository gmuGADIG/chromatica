extends CharacterBody2D
class_name Enemy

@export var health_component : HealthComponent
@export var hitbox : EnemyHitbox
@export var health_bar : ProgressBar
@export var colorable_component : Colorable

@export_group("Movement")
## Rate the enemy speeds up (px/sec^2)
@export var acceleration : float = 3000.0
## Rate the enemy slows down when it has no movement target (px/sec^2)
@export var deceleration : float = 4000.0
## Top walking speed (px/sec)
@export var max_velocity : float = 300.0
## How fast the enemy sheds speed when going faster than max_velocity (e.g. after a leap)
@export var damping : float = 6000.0

@export_group("Player Awareness")
## Offset from the player's origin (their feet) to the point enemies aim at
@export var player_center_offset : Vector2 = Vector2(0, -120)

var _player : Player
var _dying : bool = false
var _next_player_search_msec : int = 0


func _ready() -> void:
	if health_component:
		health_component.health_depleted.connect(_on_health_depleted)
		health_component.health_changed.connect(_on_health_changed)
		if health_bar:
			health_bar.max_value = health_component.maximum_hp
			health_bar.value = health_component.hp


## Returns the player, or null if there isn't one in the scene.
## Looks in the "player" group first, then falls back to searching the scene
## (throttled, so a scene without a player doesn't get scanned every frame).
func get_player() -> Player:
	if is_instance_valid(_player):
		return _player
	if Time.get_ticks_msec() < _next_player_search_msec:
		return null

	var found := get_tree().get_first_node_in_group("player") as Player
	if found == null and get_tree().current_scene:
		var matches := get_tree().current_scene.find_children("*", "Player", true, false)
		if not matches.is_empty():
			found = matches[0] as Player

	if found == null:
		_next_player_search_msec = Time.get_ticks_msec() + 500
		return null

	_player = found
	# The player's body shares a physics layer with the world for now,
	# so make sure enemies never get blocked by it.
	add_collision_exception_with(_player)
	return _player


## World position of the point enemies aim at / check line of sight to.
func get_player_center() -> Vector2:
	var player := get_player()
	if player == null:
		return global_position
	return player.global_position + player_center_offset


func die() -> void:
	queue_free()


func _on_health_changed(new_health: int) -> void:
	if health_bar:
		health_bar.value = new_health


func _on_health_depleted() -> void:
	if _dying:
		return
	_dying = true
	die()
