extends Area2D
class_name EnemyHurtbox
## Damages the player while overlapping them. Re-hits every [member rehit_delay]
## seconds if the player stays inside.
## Place on collision layer 0; the mask must include the layer the PlayerHitbox is on.

@export var damage : int = 1
## Seconds before this hurtbox can damage the player again
@export var rehit_delay : float = 1.0

signal hit_player

var _cooldown : float = 0.0


func _physics_process(delta: float) -> void:
	_cooldown = maxf(_cooldown - delta, 0.0)
	if _cooldown > 0.0:
		return
	for area in get_overlapping_areas():
		if try_damage_player(area, damage):
			_cooldown = rehit_delay
			hit_player.emit()
			return


## Damages the player if [param area] is the player's hitbox. Returns true if it was.
static func try_damage_player(area: Area2D, amount: int) -> bool:
	# Areas on the same layer as the PlayerHitbox (other enemies' hitboxes, etc.)
	# also show up, so only accept ones that belong to the Player.
	if not (area.get_parent() is Player) or not area.has_method("hit"):
		return false
	var info := DamageInfo.new()
	info.damage = amount
	area.call("hit", info)
	return true
